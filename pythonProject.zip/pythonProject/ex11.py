
a = int(input("Digite o primeiro lado: "))
b = int(input("Digite o segundo lado: "))
c = int(input("Digite o terceiro lado: "))


if a + b > c and a + c > b and b + c > a:
    print("É um triângulo válido.")
else:
    print("Não forma um triângulo.")
