numero = [5, 7, 30]

if numero[0] > numero[1] and numero[0] > numero[2]:
    print('o primeiro numero é o maior')

elif numero[1] > numero[0] and numero[1] > numero[2]:
    print('o segundo numero é o maior')

else:
    print('o terceiro numero é maior')