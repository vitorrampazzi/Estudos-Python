numero = int(input('escreva um numero'))

if numero > 10 and numero < 50:

    print('esta entre os numeros')
else:
    print('nao esta dentro dos numeros')