numero = int(input('escreva um numero'))

if numero > 0:
    print('o numero é positivo')
elif numero < 0:
    print('o numero é negativo')
else:
    print('é zero')
