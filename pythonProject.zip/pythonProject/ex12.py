num = int(input('escreva um numero'))

if (num % 2) == 0:
    print('o numero é par')


elif (num % 2) == 1:
    print('o numero é impar')