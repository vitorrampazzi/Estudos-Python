lista = [4, 2]

if (lista[0] % lista[1]) == 0:
    print('ele é divisivel')