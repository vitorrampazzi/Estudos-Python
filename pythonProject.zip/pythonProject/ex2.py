nota1 = 5
nota2 = 9
nota3 = 2

media = (nota1 + nota2 + nota3) / 3

if media >= 7:
    print('aprovado')
else:
    print('desaprovado')