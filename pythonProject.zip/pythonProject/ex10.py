mes = input('insira o mes q eu te falo quantos dias tem')

match mes:
    case 'janeiro':
        print('30')
    case 'fevereiro':
        print('28')
    case 'março':
        print('31')
    case 'abril':
        print('30')
    case 'maio':
        print('31')
    case 'junho':
        print('30')
    case 'julho':
        print('31')
    case 'agosto':
        print('31')
    case 'setembro':
        print('30')
    case 'outubro':
        print('31')
    case 'novembro':
        print('30')
    case 'dezembro':
        print('31')
