lista = ['kaneto', 'vitaoooooooooooooooooo', 'dan']

lista1 = len(lista[0])
lista2 = len(lista[1])
lista3 = len(lista[2])

if lista1 > lista2 and lista1 > lista3:
    print('a primeira palavra é maior')

elif lista2 > lista1 and lista2 > lista3:
    print('a segunda palavra é maior')

else:
    print('a terceira palavra é maior')


