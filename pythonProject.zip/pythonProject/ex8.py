lista1 = int(input('escreva um numero'))
lista2 = int(input('escreva um numero'))
lista3 = int(input('escreva um numero'))

lista = (lista1, lista2, lista3)

if lista[0] == lista[1] == lista[2]:
    print('tudo igual')

elif lista[0] != lista[1] != lista[2]:
    print('tudo diferente')

elif lista[0] == lista[1] or lista[1] == lista[2] or lista[0] == lista[2]:
    print('apenas dois sao iguais')