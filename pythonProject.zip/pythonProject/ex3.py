idade = int(input('me fale a sua idade '))

if idade >= 18:
    print('voce e maior')
else:
    print('voce e menor')