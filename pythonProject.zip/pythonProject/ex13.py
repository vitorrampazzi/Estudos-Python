lista = ['maça', 'banana', 'morango']

if 'melancia' in lista:
    print('melancia ta na lista')
else:
    print('nao esta na lista')