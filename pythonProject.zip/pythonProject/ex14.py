lista = [12, 12]

if lista[0] > lista[1]:
    print('o primeiro numero é maior')
elif lista[1] > lista[0]:
    print('o segundo numero é maior')

elif lista[0] == lista[1]:
    print('os dois sao iguais')